﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Book_Rental_App.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;


namespace Book_Rental_App.Controllers
{
    public class RentalListController : Controller
    {
        private readonly AppDbConext _context;

        private readonly UserManager<Customer> userManager;
        public RentalListController(AppDbConext context, UserManager<Customer> userManager)
        {
            _context = context;
            this.userManager = userManager;
        }
        public async Task<IActionResult> Index()
        {
            return View(await _context.Books.ToListAsync());
        }

        [HttpGet]
        public async Task<IActionResult> ConfirmRent(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _context.Books.FindAsync(id);
            
            if (book == null)
            {
                return NotFound();
            }
            return View(book);
        }

        public async Task<IActionResult> RentedBooks()
        {
            var appDbConext = _context.RentedBooks.Include(r => r.book).Include(r => r.customer);
            return View(await appDbConext.ToListAsync());
        }
        


        public async Task<IActionResult> ConfirmRentPost(int id)
        {
            ViewBag.email = userManager.GetUserId(HttpContext.User);
            
            RentedBook rentedBook = new RentedBook();
            rentedBook.book = await _context.Books.FindAsync(id);
            rentedBook.book.Quantity--;
            rentedBook.customer = await _context.Customers.FindAsync(userManager.GetUserId(HttpContext.User));
            
            _context.RentedBooks.Add(rentedBook);
            _context.SaveChanges();
            return RedirectToAction("Index", "RentalList");
        }

    }
}
