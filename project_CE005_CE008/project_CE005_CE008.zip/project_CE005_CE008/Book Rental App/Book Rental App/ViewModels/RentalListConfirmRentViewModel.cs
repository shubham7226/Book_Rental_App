﻿using Book_Rental_App.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Book_Rental_App.ViewModels
{
    public class RentalListConfirmRentViewModel
    {
        public RentedBook rentedBook { get; set; }
        
    }
}
