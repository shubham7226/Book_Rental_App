﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Book_Rental_App.Models;

namespace Book_Rental_App.ViewModels
{
    public class CreateBookViewModel
    {
        [Display(Name = "Book Title")]
        public string BookName { get; set; }
        
        [Display(Name = "Author Name")]
        public string AuthorName { get; set; }
        
        public int Quantity { get; set; }
        
        public int Price { get; set; }
        
        [Display(Name = "Total Pages")]
        public int NoOfPages { get; set; }

        [Required]
        public Genre Genre { get; set; }

        public string Description { get; set; }
    }
}
