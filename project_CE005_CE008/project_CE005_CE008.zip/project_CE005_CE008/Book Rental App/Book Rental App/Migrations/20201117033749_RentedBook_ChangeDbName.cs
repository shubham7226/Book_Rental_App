﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Book_Rental_App.Migrations
{
    public partial class RentedBook_ChangeDbName : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RentedBook_Books_bookId",
                table: "RentedBook");

            migrationBuilder.DropForeignKey(
                name: "FK_RentedBook_AspNetUsers_customerId",
                table: "RentedBook");

            migrationBuilder.DropPrimaryKey(
                name: "PK_RentedBook",
                table: "RentedBook");

            migrationBuilder.RenameTable(
                name: "RentedBook",
                newName: "RentedBooks");

            migrationBuilder.RenameIndex(
                name: "IX_RentedBook_customerId",
                table: "RentedBooks",
                newName: "IX_RentedBooks_customerId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_RentedBooks",
                table: "RentedBooks",
                columns: new[] { "bookId", "customerId" });

            migrationBuilder.AddForeignKey(
                name: "FK_RentedBooks_Books_bookId",
                table: "RentedBooks",
                column: "bookId",
                principalTable: "Books",
                principalColumn: "BookId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_RentedBooks_AspNetUsers_customerId",
                table: "RentedBooks",
                column: "customerId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RentedBooks_Books_bookId",
                table: "RentedBooks");

            migrationBuilder.DropForeignKey(
                name: "FK_RentedBooks_AspNetUsers_customerId",
                table: "RentedBooks");

            migrationBuilder.DropPrimaryKey(
                name: "PK_RentedBooks",
                table: "RentedBooks");

            migrationBuilder.RenameTable(
                name: "RentedBooks",
                newName: "RentedBook");

            migrationBuilder.RenameIndex(
                name: "IX_RentedBooks_customerId",
                table: "RentedBook",
                newName: "IX_RentedBook_customerId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_RentedBook",
                table: "RentedBook",
                columns: new[] { "bookId", "customerId" });

            migrationBuilder.AddForeignKey(
                name: "FK_RentedBook_Books_bookId",
                table: "RentedBook",
                column: "bookId",
                principalTable: "Books",
                principalColumn: "BookId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_RentedBook_AspNetUsers_customerId",
                table: "RentedBook",
                column: "customerId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
