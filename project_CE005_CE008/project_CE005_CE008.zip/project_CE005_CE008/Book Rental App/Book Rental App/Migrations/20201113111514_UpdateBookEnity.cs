﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Book_Rental_App.Migrations
{
    public partial class UpdateBookEnity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BookOwnerId",
                table: "Books");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "BookOwnerId",
                table: "Books",
                type: "int",
                nullable: true);
        }
    }
}
