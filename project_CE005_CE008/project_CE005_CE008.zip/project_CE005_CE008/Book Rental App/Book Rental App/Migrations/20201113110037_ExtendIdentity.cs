﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Book_Rental_App.Migrations
{
    public partial class ExtendIdentity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "BookOwnerId",
                table: "Books",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "customerId",
                table: "Books",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Name",
                table: "AspNetUsers",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Books_customerId",
                table: "Books",
                column: "customerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Books_AspNetUsers_customerId",
                table: "Books",
                column: "customerId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Books_AspNetUsers_customerId",
                table: "Books");

            migrationBuilder.DropIndex(
                name: "IX_Books_customerId",
                table: "Books");

            migrationBuilder.DropColumn(
                name: "BookOwnerId",
                table: "Books");

            migrationBuilder.DropColumn(
                name: "customerId",
                table: "Books");

            migrationBuilder.DropColumn(
                name: "Name",
                table: "AspNetUsers");
        }
    }
}
