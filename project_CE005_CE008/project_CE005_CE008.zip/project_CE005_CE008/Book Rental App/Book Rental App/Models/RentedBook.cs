﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Book_Rental_App.Models
{
    public class RentedBook
    {
        public int bookId { get; set; }
        public Book book { get; set; }

        public string customerId { get; set; }
        public Customer customer { get; set; }
    }
}
