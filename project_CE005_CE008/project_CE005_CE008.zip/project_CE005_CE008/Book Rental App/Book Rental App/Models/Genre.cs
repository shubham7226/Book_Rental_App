﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Book_Rental_App.Models
{
    public enum Genre
    {
        Autobiography,
        Textbook,
        Science,
        Fairytale,
        Others
    }
}
