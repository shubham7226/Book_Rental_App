﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Book_Rental_App.Models
{
    public class Customer : IdentityUser
    {
        [Required]
        public string Name { get; set; }
        public ICollection<Book> Books { get; set; }

        public IList<RentedBook> rentedBooks { get; set; }
    }
}
