﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Book_Rental_App.Models
{
    public class AppDbConext : IdentityDbContext<Customer>
    {
        public AppDbConext(DbContextOptions<AppDbConext> options)
            :base(options)
        {

        }
        public DbSet<Book> Books { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<RentedBook> RentedBooks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<RentedBook>().HasKey(pt => new { pt.bookId, pt.customerId });
            modelBuilder.Entity<RentedBook>().
                    HasOne(pt => pt.book).WithMany(pt => pt.rentedBooks).HasForeignKey(p => p.bookId);
            
            modelBuilder.Entity<RentedBook>().
                    HasOne(pt => pt.customer).WithMany(pt => pt.rentedBooks).HasForeignKey(p => p.customerId);
        }
    }
}
